#!/usr/bin/env python3
# -*- coding: latin-1 -*-
#
# $Id: graphic_display.py,v 1.10 2021/08/28 09:45:31 bob Exp $
# Raspberry Pi display routines
# Graphic screen routines used by touch graphic screen
#
# Author : Bob Rathbone
# Site   : http://www.bobrathbone.com
#
# License: GNU V3, See https://www.gnu.org/copyleft/gpl.html
#
# Disclaimer: Software is provided as is and absolutly no warranties are implied or given.
#        The authors shall not be liable for any loss or damage however caused.
#

import os,sys
import time,pwd
import socket
import pdb
from config_class import Configuration

# No interrupt routine if none supplied
def no_interrupt():
    return False

# Lcd Class 
class GraphicDisplay:
    columns = 100
    rows = 21
    size = [600,400]
    font = None
    current_row = 1
    current_column = 1
    delay = 15
    config = Configuration()
    scroll_speed = 0.25
    scroll_delay = 0

    # Display window modes
    MAIN = 0
    RSS = 1
    INFO = 2
    LAST = 2
    mode = MAIN

    # Search modes
    SEARCH_LIST = 0
    SEARCH_PLAYLIST = 1
    SEARCH_ARTISTS = 2
    search_mode = SEARCH_LIST

    # Scroll line values
    textIndex = [0,0,0,0]
    holdCountBegin = [delay,delay,delay,delay,delay]
    holdCountEnd = [delay,delay,delay,delay,delay]
    lineText = ['','','','','']

    def __init__(self,font):
        self.font = font
        self.size = self.config.screen_size
        self.scroll_speed = self.config.scroll_speed
        self.setSize(self.size)
        return

    # Get display columns 
    def getWidth(self):
        return self.columns

    # Get display rows 
    def getRows(self):
        return self.rows

    # Get display lines (compatability for message class) 
    def getLines(self):
        return self.rows

    # Get display Columns 
    def getColumns(self):
        return self.columns

    # Get row x position
    def getRowPos(self,row):
        self.current_row = row
        h = self.averageFontSize[1]
        pos = int(row * h * 1.5)
        return pos

    # Get next row position
    def getNextRow(self):
        self.current_row += 1
        return self.getRowPos(self.current_row)

    # Get row x position
    def getColumnPos(self,column):
        w = self.averageFontSize[0]
        pos =  int(column * w / 1.1)
        return pos

    # Get window title 
    def getWindowTitle(self,radio):
        version = radio.getVersion()
        hostname = socket.gethostname()
        title = self.config.window_title
        title = title.replace('%V',version)
        title = title.replace('%H',hostname)
        return title

    # Set the display size, rows and columns
    def setSize(self,size):
        self.size = size
        self.averageFontSize = self.font.size("W")
        w = self.averageFontSize[0]
        h = self.averageFontSize[1]
        self.columns = int(1.1 * self.size[0]/w)
        self.rows = int(self.size[1]/(h*1.5))
        return size 

    # Scroll text routine
    def scroll(self,text,line,max_columns):
        idx = line-1
        index = self.textIndex[idx]

        # Has the line text changed then reset
        if text != self.lineText[idx]:  
            index = 0
            self.lineText[idx] = text
            self.scroll_delay = time.time() + 2

        leng = len(text)

        newText = text[index:(max_columns + index)]

        # Increment index and check
        now = time.time()
        if now > self.scroll_delay:
            self.scroll_delay = now + self.scroll_speed
            index += 1

        # this delays scrolling at beginning of display
        if self.holdCountBegin[idx] > 0:
            self.holdCountBegin[idx] -= 1
            index = 0

        # this delays scrolling at end of scroll
        if (index + len(newText)) > leng:
            if self.holdCountEnd[idx] < 1:
                self.holdCountEnd[idx] = self.delay
                self.holdCountBegin[idx] = self.delay
                self.textIndex[idx] = 0
            else:
                self.holdCountEnd[idx] -= 1
        else:
            self.textIndex[idx] = index
            # Add a space to prevent rss_class.scrollRssFeed from
            # thinking that the end has been reached before delay count 
            # has been exhausted.
            newText = newText + ' '

        return newText
        
    # Cycle through display modes
    def cycleMode(self):
        self.mode += 1
        if self.mode > self.LAST:
            self.mode = self.MAIN
        return self.mode

    # Set display mode (Source change)
    def setMode(self,mode):
        self.mode = mode
        if self.mode > self.LAST:
            self.mode = self.MAIN
        return self.mode

    # Get display mode
    def getMode(self):
        return self.mode

    # Get search mode
    def getSearchMode(self):
        return self.search_mode

    # Get search mode
    def setSearchMode(self,mode):
        self.search_mode = mode

    # Cycle search mode
    def cycleSearchMode(self):
        self.search_mode += 1
        if self.search_mode > self.SEARCH_ARTISTS:
            self.search_mode = self.SEARCH_LIST
        return self.search_mode

    # Start column
    def getStartColumn(self):
        cols = self.columns
        if cols < 50:
            startColumn = 3
        elif cols < 70:
            startColumn = 7.5
        elif cols < 90:
            startColumn = 10
        else:
            startColumn = 20
        return startColumn

# End of Graphic Screen class

### Test scroll routine ###
if __name__ == "__main__":
    import pygame
    pygame.font.init()
    font = pygame.font.SysFont('freesans', 13)
    display = GraphicDisplay(font)
    text = "ABCDEFGHIJKLMNOPQRSTUVWXYX 01234567890"
    try:
        while True:
            print(display.scroll(text,1,20))
            time.sleep(0.5)

    except KeyboardInterrupt:
        print("\nExit")
        sys.exit(0)
# End of test routine

# set tabstop=4 shiftwidth=4 expandtab
# retab
